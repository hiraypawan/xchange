# Extension Icons

This extension has been configured to work without icons temporarily.

To add proper icons later:
1. Create icon16.png (16x16 pixels)
2. Create icon32.png (32x32 pixels) 
3. Create icon48.png (48x48 pixels)
4. Create icon128.png (128x128 pixels)

Then update manifest.json to include the icon references.